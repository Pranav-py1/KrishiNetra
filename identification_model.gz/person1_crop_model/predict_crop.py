from pathlib import Path

import numpy as np
import torch
import torch.nn as nn

from PIL import Image
from torchvision import transforms
from torchvision.models import mobilenet_v2


# --------------------------------------------------
# Configuration
# --------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parents[2]

MODEL_PATH = PROJECT_ROOT / "models/crop/crop_model.pth"
PROFILE_PATH = PROJECT_ROOT / "models/crop/crop_feature_profiles.npz"

DEVICE = torch.device(
    "cuda" if torch.cuda.is_available() else "cpu"
)

CONFIDENCE_THRESHOLD = 0.80


# --------------------------------------------------
# Load trained classifier
# --------------------------------------------------

checkpoint = torch.load(
    MODEL_PATH,
    map_location=DEVICE,
    weights_only=True
)

CLASSES = checkpoint["classes"]

model = mobilenet_v2(weights=None)
model.classifier[1] = nn.Linear(
    model.last_channel,
    len(CLASSES)
)

model.load_state_dict(checkpoint["model_state_dict"])
model = model.to(DEVICE)
model.eval()


# --------------------------------------------------
# Load feature profiles
# --------------------------------------------------

profiles = np.load(PROFILE_PATH)

PROFILE_CLASSES = profiles["classes"].tolist()
CENTROIDS = profiles["centroids"]
DISTANCE_THRESHOLDS = profiles["thresholds"]

if PROFILE_CLASSES != CLASSES:
    raise ValueError(
        "Feature profile classes do not match model classes."
    )

CLASS_TO_INDEX = {
    crop: index for index, crop in enumerate(CLASSES)
}


# --------------------------------------------------
# Image preprocessing
# --------------------------------------------------

transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(
        mean=[0.485, 0.456, 0.406],
        std=[0.229, 0.224, 0.225]
    )
])


# --------------------------------------------------
# Crop prediction
# --------------------------------------------------

def predict_crop(image):

    """
    Predict crop using MobileNetV2 and feature-distance rejection.
    """

    if isinstance(image, (str, Path)):
        with Image.open(image) as img:
            image = img.convert("RGB")
    else:
        image = image.convert("RGB")

    image_tensor = transform(image).unsqueeze(0).to(DEVICE)

    with torch.no_grad():

        # Original MobileNetV2 prediction
        outputs = model(image_tensor)

        probabilities = torch.softmax(outputs, dim=1)

        confidence, predicted_index = probabilities.max(dim=1)

        # Extract 1280-dimensional feature vector
        features = model.features(image_tensor)

        features = nn.functional.adaptive_avg_pool2d(
            features, (1, 1)
        )

        features = torch.flatten(features, 1)

    crop_name = CLASSES[predicted_index.item()]
    confidence_value = float(confidence.item())

    feature_vector = features.squeeze(0).cpu().numpy().astype(
        np.float64
    )

    feature_norm = np.linalg.norm(feature_vector)

    feature_vector /= max(feature_norm, 1e-12)

    # Compare with the centroid of the classifier-predicted crop
    crop_index = CLASS_TO_INDEX[crop_name]

    centroid = CENTROIDS[crop_index]

    distance = float(
        1.0 - np.dot(feature_vector, centroid)
    )

    threshold = float(
        DISTANCE_THRESHOLDS[crop_index]
    )

    confidence_rejected = (
        confidence_value < CONFIDENCE_THRESHOLD
    )

    distance_rejected = (
        distance > threshold
    )

    supported = not (
        confidence_rejected or distance_rejected
    )

    if not supported:

        reasons = []

        if confidence_rejected:
            reasons.append("low confidence")

        if distance_rejected:
            reasons.append("unusual feature distance")

        return {
            "crop": "Unknown",
            "predicted_crop": crop_name,
            "confidence": round(confidence_value, 4),
            "feature_distance": round(distance, 6),
            "distance_threshold": round(threshold, 6),
            "supported": False,
            "message": (
                "Image rejected: " + " and ".join(reasons) + "."
            )
        }

    return {
        "crop": crop_name,
        "confidence": round(confidence_value, 4),
        "feature_distance": round(distance, 6),
        "distance_threshold": round(threshold, 6),
        "supported": True,
        "message": "Crop identified successfully."
    }


# --------------------------------------------------
# Command-line testing
# --------------------------------------------------

if __name__ == "__main__":

    import sys

    if len(sys.argv) != 2:
        print(
            "Usage: python predict_crop.py path/to/leaf.jpg"
        )
        raise SystemExit(1)

    result = predict_crop(sys.argv[1])

    print("\nCROP PREDICTION")
    print("----------------")

    for key, value in result.items():
        print(f"{key}: {value}")
